{
 :server-port 8080
 :users {"admin" "hello"}
 :default-node ""
}